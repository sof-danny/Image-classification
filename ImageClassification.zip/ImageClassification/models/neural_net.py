"""Neural network model."""

from typing import Sequence

import numpy as np


class NeuralNetwork:
    """A multi-layer fully-connected neural network. The net has an input
    dimension of N, a hidden layer dimension of H, and performs classification
    over C classes. We train the network with a cross-entropy loss function and
    L2 regularization on the weight matrices.

    The network uses a nonlinearity after each fully connected layer except for
    the last. The outputs of the last fully-connected layer are passed through
    a softmax, and become the scores for each class."""

    def __init__(
        self,
        input_size: int,
        hidden_sizes: Sequence[int],
        output_size: int,
        num_layers: int,
        eps: float,
        b1: float,
        b2: float,
        t: int,
    ):
        """Initialize the model. Weights are initialized to small random values
        and biases are initialized to zero. Weights and biases are stored in
        the variable self.params, which is a dictionary with the following
        keys:

        W1: 1st layer weights; has shape (D, H_1)
        b1: 1st layer biases; has shape (H_1,)
        ...
        Wk: kth layer weights; has shape (H_{k-1}, C)
        bk: kth layer biases; has shape (C,)

        Parameters:
            input_size: The dimension D of the input data
            hidden_size: List [H1,..., Hk] with the number of neurons Hi in the
                hidden layer i
            output_size: The number of classes C
            num_layers: Number of fully connected layers in the neural network
        """
        self.input_size = input_size
        self.hidden_sizes = hidden_sizes
        self.output_size = output_size
        self.num_layers = num_layers
        self.eps=eps
        self.b1=b1
        self.b2 =b2
        self.t= t

        assert len(hidden_sizes) == (num_layers - 1)
        sizes = [input_size] + hidden_sizes + [output_size] # Concatenate the sizes

        self.params = {}
        for i in range(1, num_layers + 1): # num_layers W matrices and biases
            self.params["W" + str(i)] = np.random.randn(sizes[i - 1], sizes[i]) / np.sqrt(sizes[i - 1]) # ?? Initialization scheme
            self.params["b" + str(i)] = np.zeros(sizes[i])


########################################################################################
    def linear(self, W: np.ndarray, X: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Fully connected (linear) layer.

        Parameters:
            W: the weight matrix, size = layer(n-1) * layer(n) -> So input should be pre multiplied (as a row vector)
            X: Input data of shape (N, D). Each row X[i] is a training or testing sample
            b: the bias, row vector of size of next layer

        Returns: Output of the linear layer
        """
        N = X.shape[0] # Number of training/test data points
        B = np.repeat(b[np.newaxis,:],N,axis=0) # b = [1,2,3] => B = [[1,2,3],[1,2,3].......[1,2,3]], as many rows as data points
        Y = X@W + B
        return Y

    def relu(self, X: np.ndarray) -> np.ndarray:
        """Rectified Linear Unit (ReLU)"""
        return np.maximum(X,0) # Note: Maximum applies elementwise (unlike np.max)

    def softmax(self, X: np.ndarray) -> np.ndarray: #applies stable softmax to each row
        """The softmax function.
        Input:
            X: Input data of shape (N, D). Each X[i] is a training or testing sample
        Output: Apply softmax along each row (representing one data input)
        """
        temp = np.exp( X - np.max(X, axis=1)[:,np.newaxis] )
        return temp/np.sum(temp,axis=1)[:,np.newaxis]


###########################################################################################
    def relu_grad(self, out_grad: np.ndarray, op:np.ndarray, inp:np.ndarray, W: np.ndarray ):
        """Gradient of a linear + ReLU layer
        out_grad = incoming gradient backwards i.e gradient of error wrt output of the layer. Size = N*output_size of the layer (Each row is one training sample)
        op = output of the layer in forward pass at current weights. Size = same as above
        inp = current set of inputs that gave the output op. Size = N*size_of_input to the layer
        W = current weights of the layer. Size = input_size*output_size

        Output:
        W_grad = gradient for weight matrix of current layer. Size (input_size*output_size of layer)
        b_grad = gradient for bias vector of current layer. Size(1*output_size of layer)
        x_grad = gradient of error wrt input, to be passed backwards to previous layer. Size(1*input_size of layer)
        """
        N = inp.shape[0] # number of samples in the minibatch

        z_tilde = np.multiply(out_grad, (op>0)*1.0 ) # np.multiply is elementwise multiply
        W_grad = np.transpose(inp) @ z_tilde
        b_grad = np.ones(N) @ z_tilde
        x_grad = z_tilde @ np.transpose(W)

        return W_grad, b_grad, x_grad

    def softmax_cross_entropy_grad(self, y: np.ndarray, op:np.ndarray, inp:np.ndarray, W: np.ndarray ):
        """Gradient of a linear + softmax layer as last layer with cross-entropy loss,
        y = correct class for traing data. Size = (N,), integer, 0 <= y[i] < C
        op = output of the layer in forward pass at current weights. Size = N*output_size of the layer
        inp = current set of inputs that gave the output op. Size = N*size_of_input to the layer
        W = current weights of the layer. Size = input_size*output_size

        Output:
        W_grad = gradient for weight matrix of current layer. Size (input_size*output_size of layer)
        b_grad = gradient for bias vector of current layer. Size(1*output_size of layer)
        x_grad = gradient of error wrt input, to be passed backwards to previous layer. Size(1*input_size of layer)
        """
        N = inp.shape[0] # number of samples in the minibatch

        pred_onehot = np.zeros((N,self.output_size))
        pred_onehot[range(N),y] = 1 # Size (N,C) with each row being one hot. Set 1 at (0,y[0]), (1,y[1])......(N-1,y[N-1])


        z_tilde = op - pred_onehot

        W_grad = np.transpose(inp) @ z_tilde
        b_grad = np.ones(N) @ z_tilde
        x_grad = z_tilde @ np.transpose(W)

        return W_grad, b_grad, x_grad

##########################################################################################

    def reg_loss(self): # Compute regularization loss
        loss = 0.0
        for i in range(1,self.num_layers+1):
            W = self.params["W" + str(i)]
            b = self.params["b" + str(i)]
            loss = loss + np.sum(W*W) +np.sum(b*b) # * - element wise multiply
        return loss

    def get_accuracy(self, X, y):
        Z = self.forward(X) # Output of final layer

        pred = np.argmax(Z,axis=1) # Prediction by the network
        accuracy = np.sum(y==pred)/len(y)
        return accuracy

    def get_loss(self, y, reg): # A forward must be run before using this
        N = y.shape[0]
        Z = self.outputs["W" + str(self.num_layers)] # Output of final layer
        
        prob_y = Z[range(N),y] # Likelihood predicted for correct classes
        loss = (reg/2)*self.reg_loss() - (1/N)*np.sum(np.log(prob_y))
        return loss


    def compute_grad(self, layer_type: str, layer_no: int, y:np.ndarray, reg:float):

        N   = y.shape[0]
        inp =  self.outputs["W" + str(layer_no-1)] # input to layer = output of previous layer
        W   =  self.params["W" + str(layer_no)] # Weight matrix between current and previous layer
        b   =  self.params["b" + str(layer_no)]
        op  =  self.outputs["W" + str(layer_no)] # output of the layer

        if layer_type == 's': # Final Linear+Softmax layer
            assert layer_no == self.num_layers
            W_grad, b_grad, x_grad = self.softmax_cross_entropy_grad(y, op, inp, W)
        elif layer_type == 'r': # Linear+ReLu layer
            assert layer_no < self.num_layers
            x_grad = self.gradients["X" + str(layer_no+1)] # input gradient from next layer is ouput gradient of current layer
            W_grad, b_grad, x_grad = self.relu_grad(x_grad, op, inp, W)
        else:
            assert "Error"

        # Save gradients
        self.gradients["W" + str(layer_no)] = reg*self.params["W"+str(layer_no)] + (1/N)*W_grad #W_grad is sum of grad due to each input. We average it by dividing by N
        self.gradients["b" + str(layer_no)] = reg*self.params["b"+str(layer_no)] + (1/N)*b_grad
        self.gradients["X" + str(layer_no)] = x_grad

        return W_grad, b_grad

#######################################################################################
    def forward(self, X: np.ndarray) -> np.ndarray:
        """Compute the scores for each class for all of the data samples.
        Parameters:
            X: Input data of shape (N, D). Each X[i] is a training or testing sample

        Returns:
            Matrix of shape (N, C) where scores[i, c] is the score for class
                c on input X[i] outputted from the last layer of your network
        """
        if len(X.shape) == 1: # If Input is just one data point, i.e a np.array, then add a dimension to it s.t N=1
            assert X.shape[0] != 0
            X = X[np.newaxis,:]


        self.outputs = {} # Key W_i gives output of ith layer i.e Relu(X_(i-1)*W_i+b_i)
        # TODO: implement me. You'll want to store the output of each layer in
        # self.outputs as it will be used during back-propagation. You can use
        # the same keys as self.params. You can use functions like
        # self.linear, self.relu, and self.softmax in here.
        Z = X
        self.outputs["W" + str(0)] = Z

        for i in range(1, self.num_layers):
            Y = self.linear(self.params["W" + str(i)], Z, self.params["b" + str(i)])
            Z = self.relu(Y)
            self.outputs["W" + str(i)] = Z
        # Last layer: Softmax
        i = i+1
        assert i == self.num_layers

        Y = self.linear(self.params["W" + str(i)], Z, self.params["b" + str(i)])
        Z = self.softmax(Y) # Final class probability output
        self.outputs["W" + str(i)] = Z
        return Z


    def backward(self, y: np.ndarray, reg: float = 0.0) -> float: # A forward pass must happen before running this
        """Perform back-propagation
        Parameters:
            X: Input data of shape (N, D). Each X[i] is a training sample
            y: Vector of training labels. y[i] is the label for X[i], and each
                y[i] is an integer in the range 0 <= y[i] < C
            lr: Learning rate
            reg: Regularization strength

        Returns:
            Total loss for this batch of training samples
        """
        self.gradients = {}

        # Softmax layer gradient (with cross-entropy loss)
        self.compute_grad('s', self.num_layers, y, reg)

        # Back Prop through linear+Relu layers
        for i in range(self.num_layers-1,0,-1):
            self.compute_grad('r', i, y, reg)

        # Forward Pass after back-prop to compute accuracy and loss
        loss = self.get_loss(y, reg)
        
        return loss

    def update(       # A backward pass must happen before calling this function
        self,
        lr, #: float = 0.001,
        b1: float = 0.9,
        b2: float = 0.999,
        eps: float = 1e-8,
        opt: str = "SGD",
    ):
        """Update the parameters of the model using the previously calculated
        gradients.

        Parameters:
            lr: Learning rate
            reg: regularization factor
            b1: beta 1 parameter (for Adam)
            b2: beta 2 parameter (for Adam)
            eps: epsilon to prevent division by zero (for Adam)
            opt: optimizer, either 'SGD' or 'Adam'
        """
        # TODO: implement me. You'll want to add an if-statement that can
        # handle updates for both SGD and Adam depending on the value of opt.
        for i in range(self.num_layers,0,-1):
            self.params["W"+str(i)] = self.params["W"+str(i)] - lr*self.gradients["W"+str(i)]
            self.params["b"+str(i)] = self.params["b"+str(i)] - lr*self.gradients["b"+str(i)]
        return 0

